<section id="blog-main">
    <div class="container">
        <div class="blog-cards">
            <div class="row row-cols-md-2 row-cols-1 g-4 mt-4">

                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('pages.home.partials.post', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

            <!-- Pagination -->
            <div class="mt-4">
                <?php echo e($posts->links('pagination::bootstrap-5')); ?>

            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\Users\Abir Hasan\Desktop\Rayans Assignment\resources\views/pages/home/partials/all_post.blade.php ENDPATH**/ ?>