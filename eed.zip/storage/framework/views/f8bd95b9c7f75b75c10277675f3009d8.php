<!-- Post a Comment -->
<form action="<?php echo e(route('comments.store', $post)); ?>" method="POST" class="pt-4">
    <?php echo csrf_field(); ?>
    <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="mb-3">
        <label for="commentTextarea" class="form-label fw-bold">Leave a Comment</label>
        <textarea class="form-control" id="commentTextarea" name="body" rows="3" placeholder="Write your comment here..." required></textarea>
    </div>
    <button type="submit" class="btn btn-primary btn-md">
        Post Comment
    </button>
</form>
<?php /**PATH C:\Users\Abir Hasan\Desktop\Rayans Assignment\resources\views/pages/post_details/partials/write_comment.blade.php ENDPATH**/ ?>