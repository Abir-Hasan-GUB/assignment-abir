<!-- Comments Section -->
<div class="card mb-4 shadow-sm">
    <div class="card-body">
        <h5 class="card-title">Comments (<?php echo e($post->comments->count()); ?>)</h5>

        <!-- Comment List -->
        <ul class="list-group list-group-flush mb-4">
            <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('pages.post_details.partials.single_comment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <!-- Warning for Non-Logged-in Users -->
        <?php if(auth()->guard()->guest()): ?>
            <div id="loginWarning" class="alert alert-warning" role="alert">
                <strong>Warning:</strong> You need to
                <a href="<?php echo e(route('login')); ?>" class="alert-link">login</a> or
                <a href="<?php echo e(route('register')); ?>" class="alert-link">signup</a> to post a comment.
            </div>
        <?php endif; ?>

        <?php if(auth()->guard()->check()): ?>
            <?php echo $__env->make('pages.post_details.partials.write_comment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

    </div>
</div>
<?php /**PATH C:\Users\Abir Hasan\Desktop\Rayans Assignment\resources\views/pages/post_details/partials/comments.blade.php ENDPATH**/ ?>