<header id="header">
    <div class="container">
        <nav class="navbar navbar-expand-lg bg-body-tertiary">
            <div class="container-fluid d-flex align-items-center justify-content-between">
                <a class="navbar-brand" href="<?php echo e(route('home')); ?>">BLOG APPLICATION</a>

                <div class="loginInfo">

                    <?php if(auth()->guard()->guest()): ?>
                        <a href="<?php echo e(route('login')); ?>" class="btn btn-md btn-info px-3 text-light">Login</a>
                    <?php endif; ?>

                    <?php if(auth()->guard()->check()): ?>
                    <div class="dropdown">
                        <a class="btn btn-secondary dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                          <?php echo e(Auth::user()->name); ?>

                        </a>

                        <ul class="dropdown-menu text-center">
                          <li><a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>">Profile</a></li>
                          <li><a class="dropdown-item" href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                          <li>
                            <form action="<?php echo e(route('logout')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="submit" value="Logout" class="btn btn-sm btn-danger">
                            </form>
                          </li>
                        </ul>
                      </div>
                    <?php endif; ?>
                </div>
            </div>
        </nav>
    </div>
</header>
<?php /**PATH C:\Users\Abir Hasan\Desktop\Rayans Assignment\resources\views/layouts/header.blade.php ENDPATH**/ ?>