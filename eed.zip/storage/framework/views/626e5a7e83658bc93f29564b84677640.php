<section id="blog-details">
    <div class="container my-4">

        <div class="card mb-4 shadow-sm">
            <div class="card-header bg-light">
                <h5 class="card-title"><?php echo e($post->title); ?></h5>
                <p class="text-muted d-flex align-items-center justify-content-between">
                    <small>Author: <?php echo e($post->user->name); ?></small>
                    <small>Published on: <?php echo e($post->created_at->format('d-m-Y h:i A')); ?></small>
                </p>
                <small>Category: <?php echo e($post->category->name); ?></small>
            </div>
            <div class="card-body">
                <p class="card-text pb-3">
                    <?php echo e($post->description); ?>

                </p>
            </div>
        </div>
        <?php echo $__env->make('pages.post_details.partials.comments', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</section>
<?php /**PATH C:\Users\Abir Hasan\Desktop\Rayans Assignment\resources\views/pages/post_details/partials/details.blade.php ENDPATH**/ ?>