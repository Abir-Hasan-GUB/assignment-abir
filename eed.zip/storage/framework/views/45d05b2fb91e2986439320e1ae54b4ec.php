<section id="post-box" class="pt-4">
    <div class="container">
        <?php if(Route::currentRouteName() !== 'dashboard'): ?>
            <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

        <form action="<?php echo e(route('posts.update', $post)); ?>" method="POST" class="p-3 shadow border rounded">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="row">
                <div class="col-md-7">
                    <div class="mb-3">
                        <label for="postTitle" class="form-label fw-medium">Post Title</label>
                        <input type="text" class="form-control" id="postTitle" name="title"
                            value="<?php echo e($post->title); ?>" placeholder="Enter title" required />
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="mb-3">
                        <label for="category_id" class="form-label fw-medium">Category</label>
                        <select name="category_id" id="category_id" class="form-control">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"
                                    <?php echo e($post->category_id == $category->id ? 'selected' : ''); ?>>
                                    <?php echo e($category->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="mb-3">
                <label for="postTextarea" class="form-label fw-medium">Post Details</label>
                <textarea class="form-control" id="postTextarea" rows="4" name="description"
                    placeholder="Write your description here..." required><?php echo e($post->description); ?></textarea>
            </div>
            <div class="text-center">
                <button type="submit" class="btn btn-success btn-md w-50">
                    Update
                </button>
            </div>
        </form>
    </div>
</section>
<?php /**PATH C:\Users\Abir Hasan\Desktop\Rayans Assignment\resources\views/pages/home/partials/edit_post.blade.php ENDPATH**/ ?>