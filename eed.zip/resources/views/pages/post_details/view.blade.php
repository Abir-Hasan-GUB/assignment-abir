@extends('master')

@section('contents')
    @include('pages.post_details.partials.details')
@endsection
