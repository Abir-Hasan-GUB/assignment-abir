 <!-- Footer -->
 <footer class="text-center py-3 mt-5 border-top bg-light shadow-sm">
    <p class="mb-0">© 2025 By Abir Hasan. All rights reserved.</p>
</footer>
