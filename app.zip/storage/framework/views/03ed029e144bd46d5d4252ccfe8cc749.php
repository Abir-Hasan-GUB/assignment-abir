<!-- Search Bar with Category Filter -->
<section id="filter">
    <div class="container">
        <form action="<?php echo e(route('posts.filter')); ?>" method="GET" class="my-4 shadow p-4 rounded">
            <h6 class="fw-medium text-start pb-3">Filter Post By Category</h6>
            <div class="input-group">
                <!-- Category Dropdown -->
                <select class="form-select w-25" id="categorySelect" name="category">
                    <option value="">All Categories</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>" <?php echo e(request('category') == $category->id ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button class="btn btn-primary" style="width: 150px" type="submit">
                    Filter
                </button>
            </div>
        </form>
    </div>
</section>
<?php /**PATH C:\Users\Abir Hasan\Desktop\Rayans Assignment\resources\views/pages/home/partials/filter.blade.php ENDPATH**/ ?>