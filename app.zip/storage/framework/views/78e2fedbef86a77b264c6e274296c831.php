<li class="list-group-item">
    <p class="fw-bold mb-1"><?php echo e($comment->user->name); ?></p>
    <p class="mb-1">
        <?php echo e($comment->body); ?>

    </p>
    <small class="text-muted">Posted on: <?php echo e($comment->created_at->format('d-m-Y h:i A')); ?></small>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $comment)): ?>
        <form action="<?php echo e(route('comments.destroy', $comment)); ?>" method="POST" class="mt-2" onsubmit="return confirm('Are you sure?');">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <input type="submit" value="Delete" class="btn btn-danger btn-sm">
        </form>
    <?php endif; ?>
</li>
<?php /**PATH C:\Users\Abir Hasan\Desktop\Rayans Assignment\resources\views/pages/post_details/partials/single_comment.blade.php ENDPATH**/ ?>