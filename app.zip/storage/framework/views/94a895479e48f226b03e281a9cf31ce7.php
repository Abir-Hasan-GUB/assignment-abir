<?php $__env->startSection('contents'); ?>
    <?php echo $__env->make('pages.post_details.partials.details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abir Hasan\Desktop\Rayans Assignment\resources\views/pages/post_details/view.blade.php ENDPATH**/ ?>